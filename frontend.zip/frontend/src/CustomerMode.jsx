
import { useState } from 'react';
import { shops } from './shopData';

function CustomerMode({ onBack }) {
  const [search, setSearch] = useState('');
  const [searchedProduct, setSearchedProduct] = useState('');

  const getFreshness = (lastConfirmedAt) => {
    if (!lastConfirmedAt) return 'Unverified';

    const confirmedTime = new Date(lastConfirmedAt).getTime();
    const hoursOld =
      (Date.now() - confirmedTime) / (1000 * 60 * 60);

    if (hoursOld < 0) return 'Check timestamp';
    if (hoursOld <= 24) return 'Recently confirmed';

    return 'Needs confirmation';
  };

  const results = searchedProduct
    ? shops
        .map((shop) => ({
          ...shop,
          product: shop.products.find((item) =>
            item.name
              .toLowerCase()
              .includes(searchedProduct.trim().toLowerCase())
          ),
        }))
        .filter((shop) => shop.product)
        .sort((a, b) => {
          const order = {
            confirmed: 0,
            unconfirmed: 1,
            unavailable: 2,
          };

          return (
            (order[a.product.status] ?? 3) -
              (order[b.product.status] ?? 3) ||
            a.distanceKm - b.distanceKm
          );
        })
    : [];

  return (
    <main className="hero">
      <button className="back-button" onClick={onBack}>
        ← Back to home
      </button>

      <div className="eyebrow">
        <span className="status-dot"></span>
        CUSTOMER MODE
      </div>

      <h1>
        Find it nearby.
        <br />
        <span>Shop a little smarter.</span>
      </h1>

      <p className="description">
        Search for a product and discover local shops that may have it.
      </p>

      <form
        className="search-form"
        onSubmit={(event) => {
          event.preventDefault();
          setSearchedProduct(search.trim());
        }}
      >
        <span className="search-icon">⌕</span>

        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="What are you looking for?"
          aria-label="Search for a product"
        />

        <button type="submit" className="search-button">
          Search
        </button>
      </form>

      <p className="search-hint">
        Try everyday essentials, groceries, or household products.
      </p>

      {searchedProduct && (
        <section className="results-section">
          <h2>Results for "{searchedProduct}"</h2>

          <p className="search-hint">
            Shops are ranked by stock status first, then distance.
            Stock information is demo data and may need confirmation.
          </p>

          {results.length === 0 ? (
            <p>No matching products found in our demo shops.</p>
          ) : (
            results.map((shop) => (
              <article className="shop-result" key={shop.id}>
                <div>
                  <h3>{shop.name}</h3>

                  <p>{shop.distanceKm} km away · Demo distance</p>

                  <p>
                    Freshness: {getFreshness(shop.product.last_confirmed_at)}
                  </p>

                  {shop.product.last_confirmed_at && (
                    <p>
                      Last confirmed:{' '}
                      {new Date(
                        shop.product.last_confirmed_at
                      ).toLocaleString('en-IN')}
                    </p>
                  )}

                  <p>
                    Availability:{' '}
                    {shop.product.status === 'confirmed'
                      ? 'Available (demo)'
                      : shop.product.status === 'unconfirmed'
                        ? 'Needs verification'
                        : 'Out of stock'}
                  </p>
                </div>

                <div className="result-price">
                  <strong>₹{shop.product.price}</strong>

                  <p>
                    {shop.product.status === 'unavailable'
                      ? 'Out of stock'
                      : `${shop.product.quantity} in demo stock`}
                  </p>
                </div>
              </article>
            ))
          )}
        </section>
      )}
    </main>
  );
}

export default CustomerMode;
