
import { useState } from 'react';
import './App.css';
import CustomerMode from './CustomerMode';
import ShopkeeperMode from './ShopkeeperMode';
import ExchangeBoard from './ExchangeBoard';

function App() {
  const [mode, setMode] = useState(null);

  if (mode === 'customer') {
  return <CustomerMode onBack={() => setMode(null)} />;
}

if (mode === 'shopkeeper') {
  return <ShopkeeperMode onBack={() => setMode(null)} />;
}

if (mode === 'exchange') {
  return <ExchangeBoard onBack={() => setMode('shopkeeper')} />;
}

  return (
    <div className="app">
      <header className="navbar">
        <a className="logo" href="#">
          <span className="logo-icon">S</span>
          ShopMesh<span className="logo-dot">.</span>
        </a>

        <span className="nav-label">LOCAL COMMERCE, CONNECTED</span>
      </header>

      <main className="hero">
        <div className="eyebrow">
          <span className="status-dot"></span>
          YOUR NEIGHBOURHOOD, RECONNECTED
        </div>

        <h1>
          Your next find is
          <br />
          <span>closer than you think.</span>
        </h1>

        <p className="description">
          Discover nearby shops, find what you need, and help
          local businesses make the most of every product.
        </p>

        <div className="mode-heading">HOW WOULD YOU LIKE TO EXPLORE?</div>

        <div className="mode-grid">
          <button
            className={`mode-card customer ${mode === 'customer' ? 'selected' : ''}`}
            onClick={() => setMode('customer')}
          >
            <span className="card-icon">⌕</span>
            <span className="card-tag">FOR EVERYDAY FINDS</span>
            <span className="card-title">I'm a Customer</span>
            <span className="card-description">
              Find products nearby. Compare availability and prices.
            </span>
            <span className="card-action">
              Explore local shops <span>↗</span>
            </span>
          </button>

          <button
            className={`mode-card shopkeeper ${mode === 'shopkeeper' ? 'selected' : ''}`}
            onClick={() => setMode('shopkeeper')}
          >
            <span className="card-icon">▦</span>
            <span className="card-tag">FOR LOCAL BUSINESSES</span>
            <span className="card-title">I'm a Shopkeeper</span>
            <span className="card-description">
              Manage stock, track expiry risks, and discover surplus matches.
            </span>
            <span className="card-action">
              Manage my shop <span>↗</span>
            </span>
          </button>
          <button
            className="mode-card shopkeeper"
            onClick={() => setMode('exchange')}
          >
            <span className="card-icon">⇄</span>
            <span className="card-tag">FOR LOCAL BUSINESSES</span>
            <span className="card-title">Exchange Board</span>
            <span className="card-description">
              Post surplus products and discover what other shops need.
            </span>
            <span className="card-action">
              Explore exchanges <span>↗</span>
            </span>
          </button>
        </div>

        {mode && (
          <p className="selection-message" role="status">
            {mode === 'customer'
              ? 'Customer Mode selected! Your local discovery journey starts here.'
              : 'Shopkeeper Mode selected! Your inventory tools are coming next.'}
          </p>
        )}

        <div className="trust-note">
          <span>✳</span> Built to connect local demand with local supply.
        </div>
      </main>

      <footer className="footer">
        <span>© 2026 ShopMesh</span>
        <span>BETTER CONNECTIONS. LESS WASTE.</span>
      </footer>
    </div>
  );
}

export default App;
