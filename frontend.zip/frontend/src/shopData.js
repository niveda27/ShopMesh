
export const shops = [
  {
    id: 1,
    name: 'FreshMart',
    distanceKm: 0.8,
    products: [
      {
        name: 'milk',
        price: 30,
        quantity: 12,
        status: 'confirmed',
        last_confirmed_at: '2026-10-20T09:00:00',
      },
      {
        name: 'bread',
        price: 35,
        quantity: 8,
        status: 'confirmed',
        last_confirmed_at: '2026-10-20T08:30:00',
      },
      {
        name: 'rice',
        price: 60,
        quantity: 0,
        status: 'unavailable',
      },
    ],
  },
  {
    id: 2,
    name: 'QuickStop',
    distanceKm: 1.2,
    products: [
      {
        name: 'milk',
        price: 28,
        quantity: 5,
        status: 'unconfirmed',
        last_confirmed_at: '2026-10-18T09:00:00',
      },
      {
        name: 'bread',
        price: 32,
        quantity: 0,
        status: 'unavailable',
      },
      {
        name: 'rice',
        price: 65,
        quantity: 10,
        status: 'confirmed',
        last_confirmed_at: '2026-10-19T10:00:00',
      },
    ],
  },
  {
    id: 3,
    name: 'GreenBasket',
    distanceKm: 1.7,
    products: [
      {
        name: 'milk',
        price: 32,
        quantity: 9,
        status: 'confirmed',
        last_confirmed_at: '2026-10-20T09:15:00',
      },
      {
        name: 'rice',
        price: 58,
        quantity: 6,
        status: 'confirmed',
      },
    ],
  },
  {
    id: 4,
    name: 'ValueStore',
    distanceKm: 2.4,
    products: [
      {
        name: 'bread',
        price: 29,
        quantity: 15,
        status: 'confirmed',
        last_confirmed_at: '2026-10-17T11:00:00',
      },
      {
        name: 'milk',
        price: 27,
        quantity: 0,
        status: 'unavailable',
      },
    ],
  },
  {
    id: 5,
    name: 'NightOwl',
    distanceKm: 3.1,
    products: [
      {
        name: 'milk',
        price: 31,
        quantity: 7,
        status: 'confirmed',
        last_confirmed_at: '2026-10-20T09:30:00',
      },
      {
        name: 'bread',
        price: 34,
        quantity: 4,
        status: 'unconfirmed',
        last_confirmed_at: '2026-10-18T08:00:00',
      },
    ],
  },
];
