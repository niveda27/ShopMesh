
import { useState } from 'react';

function ShopkeeperMode({ onBack }) {
  const [shopName] = useState('FreshMart');

  const [products, setProducts] = useState([
    {
      id: 1,
      name: 'Milk',
      quantity: 12,
      price: 30,
      expiryDate: '2026-10-22',
    },
    {
      id: 2,
      name: 'Bread',
      quantity: 8,
      price: 35,
      expiryDate: '2026-10-20',
    },
    {
      id: 3,
      name: 'Rice',
      quantity: 10,
      price: 60,
      expiryDate: '2027-06-30',
    },
  ]);

  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newQuantity, setNewQuantity] = useState('');

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const getExpiryInfo = (expiryDate) => {
    if (!expiryDate) return null;

    const expiry = new Date(`${expiryDate}T00:00:00`);
    const daysLeft = Math.round(
      (expiry.getTime() - today.getTime()) /
      (1000 * 60 * 60 * 24)
    );

    if (daysLeft < 0) {
      return { message: '⚠️ Expired', color: '#b91c1c' };
    }

    if (daysLeft === 0) {
      return { message: '⚠️ Expires today!', color: '#b45309' };
    }

    if (daysLeft <= 3) {
      return {
        message: `⚠️ Expires in ${daysLeft} day(s)!`,
        color: '#b45309',
      };
    }

    return null;
  };

  const reminderProducts = products.filter((product) => {
    if (!product.last_confirmed_at) return true;

    const hoursSinceConfirmation =
      (Date.now() -
        new Date(product.last_confirmed_at).getTime()) /
      (1000 * 60 * 60);

    return hoursSinceConfirmation > 24;
  });

  const updateQuantity = (id, change) => {
    setProducts((current) =>
      current.map((product) =>
        product.id === id
          ? {
              ...product,
              quantity: Math.max(0, product.quantity + change),
            }
          : product
      )
    );
  };

  const addProduct = (event) => {
    event.preventDefault();

    if (
      !newName.trim() ||
      newPrice === '' ||
      newQuantity === '' ||
      !Number.isFinite(Number(newPrice)) ||
      !Number.isFinite(Number(newQuantity)) ||
      Number(newPrice) < 0 ||
      Number(newQuantity) < 0
    ) {
      return;
    }

    setProducts((current) => [
      ...current,
      {
        id: Date.now(),
        name: newName.trim(),
        price: Number(newPrice),
        quantity: Number(newQuantity),
      },
    ]);

    setNewName('');
    setNewPrice('');
    setNewQuantity('');
  };

  return (
    <main className="hero">
      <button className="back-button" onClick={onBack}>
        ← Back to home
      </button>

      <div className="eyebrow">
        <span className="status-dot"></span>
        SHOPKEEPER MODE
      </div>

      <h1>
        Welcome back,
        <br />
        <span>{shopName}.</span>
      </h1>

      <p className="description">
        Manage your inventory and keep your shop information up to date.
      </p>

      <section className="results-section">
        <h2>🔔 Smart Confirmation Reminders</h2>

        <p className="search-hint">
          Review products whose stock information may need updating.
        </p>

        {reminderProducts.length === 0 ? (
          <p>All products are up to date!</p>
        ) : (
          reminderProducts.map((product) => (
            <article className="shop-result" key={product.id}>
              <div>
                <h3>{product.name}</h3>
                <p>Current quantity: {product.quantity}</p>
                <p>Stock confirmation needed</p>
              </div>
            </article>
          ))
        )}
      </section>

      <section className="results-section">
        <h2>Your inventory</h2>

        <p className="search-hint">
          Demo inventory — changes are temporary and reset on refresh.
        </p>

        {products.map((product) => {
          const expiryInfo = getExpiryInfo(product.expiryDate);

          return (
            <article className="shop-result" key={product.id}>
              <div>
                <h3>{product.name}</h3>

                {expiryInfo && (
                  <p
                    style={{
                      color: expiryInfo.color,
                      fontWeight: 'bold',
                    }}
                  >
                    {expiryInfo.message}
                  </p>
                )}

                {product.quantity <= 3 && (
                  <p
                    style={{
                      color: '#b45309',
                      fontWeight: 'bold',
                    }}
                  >
                    ⚠️ Low stock — only {product.quantity} units left!
                  </p>
                )}

                <p>Price: ₹{product.price}</p>
              </div>

              <div className="result-price">
                <strong>{product.quantity} units</strong>

                <div>
                  <button
                    type="button"
                    onClick={() => updateQuantity(product.id, -1)}
                    aria-label={`Decrease ${product.name} quantity`}
                  >
                    −
                  </button>
                  {' '}
                  <button
                    type="button"
                    onClick={() => updateQuantity(product.id, 1)}
                    aria-label={`Increase ${product.name} quantity`}
                  >
                    +
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      <section className="add-product-section">
        <h2>Add a new product</h2>

        <form className="search-form" onSubmit={addProduct}>
          <input
            value={newName}
            onChange={(event) => setNewName(event.target.value)}
            placeholder="Product name"
            aria-label="Product name"
            required
          />

          <input
            type="number"
            min="0"
            step="0.01"
            value={newPrice}
            onChange={(event) => setNewPrice(event.target.value)}
            placeholder="Price (₹)"
            aria-label="Product price"
            required
          />

          <input
            type="number"
            min="0"
            step="1"
            value={newQuantity}
            onChange={(event) => setNewQuantity(event.target.value)}
            placeholder="Quantity"
            aria-label="Product quantity"
            required
          />

          <button type="submit" className="search-button">
            Add product
          </button>
        </form>
      </section>
    </main>
  );
}

export default ShopkeeperMode;
