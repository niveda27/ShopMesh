
import { useState } from 'react';

const demoOffers = [
  {
    id: 1,
    shop: 'FreshMart',
    product: 'Soap bars',
    quantity: 20,
    wanted: 'Cooking oil',
    message: 'Extra soap bars available for exchange.',
  },
  {
    id: 2,
    shop: 'GreenBasket',
    product: 'Rice bags',
    quantity: 5,
    wanted: 'Wheat flour',
    message: 'Looking to exchange surplus rice.',
  },
  {
    id: 3,
    shop: 'QuickStop',
    product: 'Biscuits',
    quantity: 15,
    wanted: 'Milk packets',
    message: 'Open to a fair exchange.',
  },
];

function ExchangeBoard({ onBack }) {
  const [offers, setOffers] = useState(demoOffers);
  const [shopName, setShopName] = useState('FreshMart');
  const [product, setProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [wanted, setWanted] = useState('');
  const [message, setMessage] = useState('');
  const [search, setSearch] = useState('');
  const [notice, setNotice] = useState('');

  const [proposals, setProposals] = useState([
    {
      id: 101,
      from: 'GreenBasket',
      to: 'FreshMart',
      offer: 'Wheat flour',
      requested: 'Soap bars',
      quantity: 5,
      status: 'Pending',
    },
  ]);

  function postOffer(event) {
    event.preventDefault();

    if (!product.trim() || !wanted.trim() ||
        !Number.isInteger(Number(quantity)) ||
        Number(quantity) <= 0) {
      setNotice('Enter valid product details and a quantity above zero.');
      return;
    }

    setOffers((current) => [
      {
        id: Date.now(),
        shop: shopName.trim() || 'Demo Shop',
        product: product.trim(),
        quantity: Number(quantity),
        wanted: wanted.trim(),
        message: message.trim() || 'Open to exchange proposals.',
      },
      ...current,
    ]);

    setProduct('');
    setQuantity('');
    setWanted('');
    setMessage('');
    setNotice('Exchange offer posted!');
  }

  function sendProposal(offer) {
    if (offer.shop === shopName.trim()) {
      setNotice("You can't send a proposal to your own shop.");
      return;
    }

    const alreadySent = proposals.some(
      (proposal) =>
        proposal.from === shopName.trim() &&
        proposal.offer === offer.wanted &&
        proposal.requested === offer.product &&
        proposal.to === offer.shop &&
        proposal.status !== 'Rejected'
    );

    if (alreadySent) {
      setNotice('You have already sent a similar proposal.');
      return;
    }

    setProposals((current) => [
      {
        id: Date.now(),
        from: shopName.trim(),
        to: offer.shop,
        offer: offer.wanted,
        requested: offer.product,
        quantity: 1,
        status: 'Pending',
      },
      ...current,
    ]);

    setNotice(`Proposal sent to ${offer.shop}!`);
  }

  function updateProposal(id, status) {
    setProposals((current) =>
      current.map((proposal) =>
        proposal.id === id
          ? { ...proposal, status }
          : proposal
      )
    );

    setNotice(`Proposal marked as ${status.toLowerCase()}.`);
  }

  const filteredOffers = offers.filter((offer) => {
    const text = search.trim().toLowerCase();

    return (
      offer.product.toLowerCase().includes(text) ||
      offer.wanted.toLowerCase().includes(text) ||
      offer.shop.toLowerCase().includes(text) ||
      offer.message.toLowerCase().includes(text)
    );
  });

  const incoming = proposals.filter(
    (proposal) => proposal.to === shopName.trim()
  );

  const outgoing = proposals.filter(
    (proposal) => proposal.from === shopName.trim()
  );

  return (
    <main className="hero">
      <button className="back-button" onClick={onBack}>
        ← Back
      </button>

      <div className="eyebrow">
        <span className="status-dot" />
        SHOP-TO-SHOP EXCHANGE
      </div>

      <h1>
        Surplus stock?
        <br />
        <span>Let's exchange.</span>
      </h1>

      <p className="description">
        Share extra products and connect with shops that need them.
      </p>

      <section className="results-section">
        <h2>Your shop identity</h2>
        <label>
          Shop name
          <input
            value={shopName}
            onChange={(event) => setShopName(event.target.value)}
            placeholder="Enter your shop name"
          />
        </label>
        <p className="search-hint">
          Demo mode: choose a shop name to test incoming and outgoing
          proposals. Real shop authentication will come with the backend.
        </p>
      </section>

      <section className="results-section">
        <h2>Post an exchange offer</h2>

        <form className="exchange-form" onSubmit={postOffer}>
          <label>
            Product you have
            <input
              value={product}
              onChange={(event) => setProduct(event.target.value)}
              placeholder="e.g. Soap bars"
              required
            />
          </label>

          <label>
            Quantity available
            <input
              type="number"
              min="1"
              step="1"
              value={quantity}
              onChange={(event) => setQuantity(event.target.value)}
              placeholder="e.g. 20"
              required
            />
          </label>

          <label>
            Product you need
            <input
              value={wanted}
              onChange={(event) => setWanted(event.target.value)}
              placeholder="e.g. Cooking oil"
              required
            />
          </label>

          <label>
            Additional message
            <textarea
              value={message}
              onChange={(event) => setMessage(event.target.value)}
              placeholder="Describe your offer..."
              rows={3}
            />
          </label>

          <button className="search-button" type="submit">
            Post offer
          </button>
        </form>
      </section>

      {notice && (
        <p className="search-hint" role="status">{notice}</p>
      )}

      <section className="results-section">
        <h2>Explore exchange offers</h2>

        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search products or shops"
          aria-label="Search exchange offers"
        />

        {filteredOffers.length === 0 ? (
          <p>No matching offers found.</p>
        ) : (
          filteredOffers.map((offer) => (
            <article className="shop-result" key={offer.id}>
              <div>
                <h3>{offer.product}</h3>
                <p>Shop: {offer.shop}</p>
                <p>Available quantity: {offer.quantity}</p>
                <p>Looking for: {offer.wanted}</p>
                <p>{offer.message}</p>
              </div>

              <button
                className="search-button"
                onClick={() => sendProposal(offer)}
              >
                Propose exchange
              </button>
            </article>
          ))
        )}
      </section>

      <section className="results-section">
        <h2>Incoming proposals ({incoming.length})</h2>

        {incoming.length === 0 ? (
          <p>No proposals received by this shop yet.</p>
        ) : (
          incoming.map((proposal) => (
            <article className="shop-result" key={proposal.id}>
              <div>
                <h3>{proposal.from}</h3>
                <p>Offers: {proposal.offer}</p>
                <p>Wants: {proposal.requested}</p>
                <p>Status: {proposal.status}</p>
              </div>

              {proposal.status === 'Pending' && (
                <div>
                  <button
                    className="search-button"
                    onClick={() => updateProposal(proposal.id, 'Accepted')}
                  >
                    Accept
                  </button>
                  {' '}
                  <button
                    className="reject-button"
                    onClick={() => updateProposal(proposal.id, 'Rejected')}
                >
                    Reject
                  </button>
                </div>
              )}
            </article>
          ))
        )}
      </section>

      <section className="results-section">
        <h2>Outgoing proposals ({outgoing.length})</h2>

        {outgoing.length === 0 ? (
          <p>You haven't sent any proposals yet.</p>
        ) : (
          outgoing.map((proposal) => (
            <article className="shop-result" key={proposal.id}>
              <div>
                <h3>To: {proposal.to}</h3>
                <p>You offer: {proposal.offer}</p>
                <p>You request: {proposal.requested}</p>
                <p>Status: {proposal.status}</p>
              </div>
            </article>
          ))
        )}
      </section>

      <p className="search-hint">
        Prototype only: offers and proposals are stored in page memory.
        Accepting a proposal records its demo status but does not transfer
        inventory. Both shops must agree to a real exchange.
      </p>
    </main>
  );
}

export default ExchangeBoard;
